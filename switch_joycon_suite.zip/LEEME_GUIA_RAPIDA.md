# Guía de Instalación y Uso por BLUETOOTH (Sin Wi-Fi en la Switch)

Dado que tu Nintendo Switch **no tiene Wi-Fi funcional** pero ya tienes instalado **[MissionControl](https://github.com/ndeadly/MissionControl)**, toda la comunicación de esta aplicación está diseñada para funcionar **100% por Bluetooth Clásico (Perfil HID Gamepad)** sin usar internet ni red local.

---

## ¿Cómo funciona la conexión por Bluetooth sin Wi-Fi?

1. **En la Nintendo Switch (`MissionControl`):**
   - A partir de **[MissionControl v0.11.0+](https://github.com/ndeadly/MissionControl/discussions/797)**, el módulo incluye los parches `bluetooth_patches` que desactivan la restricción de clase de dispositivo (*Class of Device*) que Nintendo introdujo en el firmware 12.0.0.
   - Gracias a esto, la Switch acepta conexiones Bluetooth HID directamente desde teléfonos Android 9+ **sin necesidad de root**.

2. **En tu Teléfono (`SwitchBluetoothHidService.kt` + Interfaz `switch_joycon_controller.html`):**
   - El servicio nativo `SwitchBluetoothHidService.kt` utiliza la API oficial de Android `BluetoothHidDevice` para registrar el **Descriptor HID oficial de 170 bytes de Nintendo Switch**.
   - Cambia temporalmente el nombre Bluetooth a `"Pro Controller"`, `"Joy-Con (L)"` o `"Joy-Con (R)"`.
   - Responde automáticamente a los subcomandos de emparejamiento de la consola (`Output Report 0x01` → `Input Report 0x21`: información de firmware `0x02`, lectura de memoria SPI Flash de calibración `0x603D` y colores del mando `0x6050`, y asignación de luces LED de jugador `0x30`).
   - Envía a **60 Hz (cada 16 ms)** el paquete binario **`Input Report 0x30`** (49 bytes) con la máscara de botones, sticks analógicos empaquetados en 12 bits (`0..4095`) y giroscopio.

---

## Paso 1: Preparar tu Nintendo Switch (Sin Wi-Fi)

1. Asegúrate de tener una versión actualizada de **[MissionControl](https://github.com/ndeadly/MissionControl)** en tu tarjeta SD (`/atmosphere/contents/010000000000bd00` y `/atmosphere/exefs_patches/bluetooth_patches`).
2. Si tienes la consola en **Modo Avión** (porque el chip Wi-Fi no funciona), entra a **Configuración de la consola → Modo avión** y activa explícitamente la opción **Conexión Bluetooth: Sí**.
3. En el menú principal de la Switch, entra a **Mandos → Cambiar el orden o el modo de sujeción** (*Controllers → Change Grip/Order*). Quédate en esa pantalla.

---

## Paso 2: Compilar o Instalar la App en tu Android

Los navegadores web normales (Chrome/Safari) no tienen permiso del sistema operativo para fingir ser un mando Bluetooth clásico HID; por ello, Android requiere que la app corra como un `.apk` usando `BluetoothHidDevice`:

### Opción A: Compilar el proyecto incluido en este `.zip` (Con nuestra interfaz personalizada)
1. Abre **Android Studio** y crea un proyecto nuevo con *Empty Views Activity* (paquete `com.cfw.switchjoycon`, SDK mínimo API 28 / Android 9.0).
2. Copia los 3 archivos de la carpeta `android_nativo/` en tu proyecto:
   - `MainActivity.kt` → `app/src/main/java/com/cfw/switchjoycon/MainActivity.kt`
   - `SwitchBluetoothHidService.kt` → `app/src/main/java/com/cfw/switchjoycon/SwitchBluetoothHidService.kt`
   - `AndroidManifest.xml` → `app/src/main/AndroidManifest.xml`
3. Crea la carpeta `app/src/main/assets/` y pega dentro `switch_joycon_controller.html`.
4. Conecta tu teléfono por USB a la PC y pulsa **Run (▶)** en Android Studio para instalar la APK en tu celular.
5. Dentro de la app, pulsa **⚙️ Conectar Switch**, elige el modo (`Pro Controller`, `Joy-Con (L)` o `Joy-Con (R)`), toca **Conectar a la Switch** y acepta hacer visible tu teléfono por 120 segundos.

### Opción B: Alternativa directa sin usar Android Studio
Si no tienes Android Studio a la mano y quieres conectarte de inmediato aprovechando los parches de tu `MissionControl`:
1. Descarga e instala en tu Android la APK precompilada de código abierto **[JoyCon Droid v1.1.3](https://github.com/TeamJCD/JoyConDroid/releases)**.
2. Ábrela, selecciona **Pro Controller** o **Joy-Con**, acepta el permiso de visibilidad Bluetooth y entra a **Mandos → Cambiar el orden o el modo de sujeción** en tu Switch. Gracias a `MissionControl v0.11.0+`, emparejará por Bluetooth sin pedirte root.
