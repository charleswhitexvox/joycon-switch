@echo off
title Compilador Automatico APK - Switch JoyCon Bluetooth
echo ==========================================================
echo Compilando SwitchJoyCon-Bluetooth.apk...
echo ==========================================================
where gradle >nul 2>nul
if %errorlevel% neq 0 (
    echo Error: Necesitas tener Gradle e instalado el Android SDK, o subir esta carpeta a GitHub Actions.
    pause
    exit /b 1
)
call gradle assembleDebug
echo.
echo APK generada exitosamente en: app\build\outputs\apk\debug\app-debug.apk
pause
