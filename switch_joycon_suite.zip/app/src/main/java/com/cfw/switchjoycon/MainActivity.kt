package com.cfw.switchjoycon

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.bluetooth.BluetoothAdapter
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

/**
 * MainActivity.kt - Aplicación Nativa Android Bluetooth HID para Nintendo Switch (CFW)
 * ====================================================================================
 * Carga `switch_joycon_controller.html` y expone `window.AndroidBluetoothHid` para que
 * la interfaz táctil controle directamente el servicio `SwitchBluetoothHidService`
 * mediante Bluetooth clásico HID (sin usar Wi-Fi).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var btService: SwitchBluetoothHidService? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )

        requestBluetoothPermissionsIfNeeded()

        webView = WebView(this)
        setContentView(webView)

        btService = SwitchBluetoothHidService(this) { connected, message, leds ->
            val safeMsg = message.replace("'", "\\'")
            webView.evaluateJavascript(
                "if(window.onNativeBtStatus) window.onNativeBtStatus($connected, '$safeMsg', $leds);",
                null
            )
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
        }

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(BluetoothJsBridge(), "AndroidBluetoothHid")

        webView.loadUrl("file:///android_asset/switch_joycon_controller.html")
    }

    private fun requestBluetoothPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val perms = arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_ADVERTISE,
                Manifest.permission.BLUETOOTH_SCAN
            )
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, perms, 1001)
            }
        }
    }

    inner class BluetoothJsBridge {

        @JavascriptInterface
        fun startBluetoothHid(controllerType: Int) {
            btService?.start(controllerType)
        }

        @JavascriptInterface
        @SuppressLint("MissingPermission")
        fun makeDiscoverable() {
            val discoverableIntent = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).apply {
                putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120)
            }
            startActivity(discoverableIntent)
        }

        @JavascriptInterface
        fun updateButtons(rightMask: Int, sharedMask: Int, leftMask: Int) {
            btService?.updateButtonsBitmask(rightMask, sharedMask, leftMask)
        }

        @JavascriptInterface
        fun updateStick(isLeft: Boolean, x12: Int, y12: Int) {
            btService?.updateStick12Bit(isLeft, x12, y12)
        }

        @JavascriptInterface
        fun updateColors(bodyRgb: Int, buttonsRgb: Int, leftGripRgb: Int, rightGripRgb: Int) {
            btService?.updateSpiColors(bodyRgb, buttonsRgb, leftGripRgb, rightGripRgb)
        }

        @JavascriptInterface
        fun stopBluetoothHid() {
            btService?.stop()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        btService?.stop()
    }
}
