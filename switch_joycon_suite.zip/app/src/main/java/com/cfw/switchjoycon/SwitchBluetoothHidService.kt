package com.cfw.switchjoycon

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppQosSettings
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

/**
 * SwitchBluetoothHidService.kt
 * ============================
 * Implementación completa del protocolo Bluetooth HID de Nintendo Switch (Pro Controller / Joy-Con)
 * usando la API oficial de Android `BluetoothHidDevice` (Android 9.0+ / API 28+).
 *
 * Compatible SIN ROOT con Nintendo Switch CFW gracias a los parches `bluetooth_patches`
 * incluidos en MissionControl v0.11.0+.
 */
@SuppressLint("MissingPermission")
class SwitchBluetoothHidService(
    private val context: Context,
    private val onStatusChange: (connected: Boolean, message: String, playerLeds: Int) -> Unit
) {
    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager.adapter
    private var hidDevice: BluetoothHidDevice? = null
    private var connectedHost: BluetoothDevice? = null
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private var reportLoopFuture: ScheduledFuture<*>? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    // Tipo de mando emulado: 0x03 = Pro Controller, 0x01 = Joy-Con (L), 0x02 = Joy-Con (R)
    @Volatile var controllerType: Int = 0x03
    private var originalBtName: String? = null

    // Estado en vivo de botones (3 bytes) y sticks analógicos de 12 bits (0..4095, centro = 2048)
    @Volatile private var btnRight: Int = 0
    @Volatile private var btnShared: Int = 0
    @Volatile private var btnLeft: Int = 0
    @Volatile private var stickLX: Int = 2048
    @Volatile private var stickLY: Int = 2048
    @Volatile private var stickRX: Int = 2048
    @Volatile private var stickRY: Int = 2048
    @Volatile private var gyroX: Int = 0
    @Volatile private var gyroY: Int = 0
    @Volatile private var gyroZ: Int = 0

    // Colores SPI Flash (0x6050): Body RGB, Buttons RGB, Left Grip RGB, Right Grip RGB
    private val spiColors = byteArrayOf(
        0x00.toByte(), 0xC3.toByte(), 0xE3.toByte(), // Body: Neon Blue
        0x1E.toByte(), 0x23.toByte(), 0x28.toByte(), // Buttons: Dark Grey
        0x00.toByte(), 0xC3.toByte(), 0xE3.toByte(), // Left Grip: Neon Blue
        0xFF.toByte(), 0x45.toByte(), 0x54.toByte()  // Right Grip: Neon Red
    )

    private var timerCounter: Int = 0

    // Descriptor HID Oficial de 170 bytes de Nintendo Switch (Report IDs 0x21, 0x30, 0x3F y Output 0x01, 0x10)
    private val switchHidDescriptor = byteArrayOf(
        0x05.toByte(), 0x01.toByte(), 0x09.toByte(), 0x05.toByte(), 0xA1.toByte(), 0x01.toByte(),
        0x06.toByte(), 0x01.toByte(), 0xFF.toByte(), 0x85.toByte(), 0x21.toByte(), 0x09.toByte(),
        0x21.toByte(), 0x75.toByte(), 0x08.toByte(), 0x95.toByte(), 0x30.toByte(), 0x81.toByte(),
        0x02.toByte(), 0x85.toByte(), 0x30.toByte(), 0x09.toByte(), 0x30.toByte(), 0x75.toByte(),
        0x08.toByte(), 0x95.toByte(), 0x30.toByte(), 0x81.toByte(), 0x02.toByte(), 0x85.toByte(),
        0x31.toByte(), 0x09.toByte(), 0x31.toByte(), 0x75.toByte(), 0x08.toByte(), 0x96.toByte(),
        0x69.toByte(), 0x01.toByte(), 0x81.toByte(), 0x02.toByte(), 0x85.toByte(), 0x32.toByte(),
        0x09.toByte(), 0x32.toByte(), 0x75.toByte(), 0x08.toByte(), 0x96.toByte(), 0x69.toByte(),
        0x01.toByte(), 0x81.toByte(), 0x02.toByte(), 0x85.toByte(), 0x33.toByte(), 0x09.toByte(),
        0x33.toByte(), 0x75.toByte(), 0x08.toByte(), 0x96.toByte(), 0x69.toByte(), 0x01.toByte(),
        0x81.toByte(), 0x02.toByte(), 0x85.toByte(), 0x3F.toByte(), 0x05.toByte(), 0x09.toByte(),
        0x19.toByte(), 0x01.toByte(), 0x29.toByte(), 0x10.toByte(), 0x15.toByte(), 0x00.toByte(),
        0x25.toByte(), 0x01.toByte(), 0x75.toByte(), 0x01.toByte(), 0x95.toByte(), 0x10.toByte(),
        0x81.toByte(), 0x02.toByte(), 0x05.toByte(), 0x01.toByte(), 0x09.toByte(), 0x39.toByte(),
        0x15.toByte(), 0x00.toByte(), 0x25.toByte(), 0x07.toByte(), 0x75.toByte(), 0x04.toByte(),
        0x95.toByte(), 0x01.toByte(), 0x81.toByte(), 0x42.toByte(), 0x05.toByte(), 0x09.toByte(),
        0x75.toByte(), 0x04.toByte(), 0x95.toByte(), 0x01.toByte(), 0x81.toByte(), 0x01.toByte(),
        0x05.toByte(), 0x01.toByte(), 0x09.toByte(), 0x30.toByte(), 0x09.toByte(), 0x31.toByte(),
        0x09.toByte(), 0x33.toByte(), 0x09.toByte(), 0x34.toByte(), 0x16.toByte(), 0x00.toByte(),
        0x00.toByte(), 0x27.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0x00.toByte(), 0x00.toByte(),
        0x75.toByte(), 0x10.toByte(), 0x95.toByte(), 0x04.toByte(), 0x81.toByte(), 0x02.toByte(),
        0x06.toByte(), 0x01.toByte(), 0xFF.toByte(), 0x85.toByte(), 0x01.toByte(), 0x09.toByte(),
        0x01.toByte(), 0x75.toByte(), 0x08.toByte(), 0x95.toByte(), 0x30.toByte(), 0x91.toByte(),
        0x02.toByte(), 0x85.toByte(), 0x10.toByte(), 0x09.toByte(), 0x10.toByte(), 0x75.toByte(),
        0x08.toByte(), 0x95.toByte(), 0x30.toByte(), 0x91.toByte(), 0x02.toByte(), 0x85.toByte(),
        0x11.toByte(), 0x09.toByte(), 0x11.toByte(), 0x75.toByte(), 0x08.toByte(), 0x95.toByte(),
        0x30.toByte(), 0x91.toByte(), 0x02.toByte(), 0x85.toByte(), 0x12.toByte(), 0x09.toByte(),
        0x12.toByte(), 0x75.toByte(), 0x08.toByte(), 0x95.toByte(), 0x30.toByte(), 0x91.toByte(),
        0x02.toByte(), 0xC0.toByte()
    )

    fun start(type: Int = 0x03) {
        controllerType = type
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
            notifyStatus(false, "Activa el Bluetooth en tu teléfono primero", 0)
            return
        }

        // Guardar y cambiar el nombre Bluetooth para que la Switch lo identifique
        if (originalBtName == null) {
            originalBtName = bluetoothAdapter.name
        }
        val targetName = when (controllerType) {
            0x01 -> "Joy-Con (L)"
            0x02 -> "Joy-Con (R)"
            else -> "Pro Controller"
        }
        try {
            bluetoothAdapter.name = targetName
        } catch (_: Exception) {}

        bluetoothAdapter.getProfileProxy(context, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                if (profile == BluetoothProfile.HID_DEVICE) {
                    hidDevice = proxy as BluetoothHidDevice
                    registerHidApp(targetName)
                }
            }

            override fun onServiceDisconnected(profile: Int) {
                if (profile == BluetoothProfile.HID_DEVICE) {
                    hidDevice = null
                    notifyStatus(false, "Servicio Bluetooth HID desconectado", 0)
                }
            }
        }, BluetoothProfile.HID_DEVICE)
    }

    private fun registerHidApp(deviceName: String) {
        val sdpSettings = BluetoothHidDeviceAppSdpSettings(
            deviceName,
            "Wireless Gamepad",
            "Nintendo",
            0x08.toByte(), // Subclass: Gamepad
            switchHidDescriptor
        )
        // QoS para 60Hz (16.6ms)
        val inQos = BluetoothHidDeviceAppQosSettings(
            BluetoothHidDeviceAppQosSettings.SERVICE_BEST_EFFORT,
            800, 9, 0, 11250, -1
        )
        val outQos = BluetoothHidDeviceAppQosSettings(
            BluetoothHidDeviceAppQosSettings.SERVICE_BEST_EFFORT,
            800, 9, 0, 11250, -1
        )

        hidDevice?.registerApp(sdpSettings, inQos, outQos, executor, object : BluetoothHidDevice.Callback() {
            override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
                if (registered) {
                    notifyStatus(false, "Bluetooth HID registrado como '$deviceName'. Abre 'Cambiar el orden o el modo de sujeción' en tu Switch.", 0)
                } else {
                    notifyStatus(false, "Error al registrar perfil Bluetooth HID en Android.", 0)
                }
            }

            override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
                when (state) {
                    BluetoothProfile.STATE_CONNECTED -> {
                        connectedHost = device
                        notifyStatus(true, "Conectado por Bluetooth a Nintendo Switch (${device.name ?: device.address})", 1)
                        startInputReportLoop()
                    }
                    BluetoothProfile.STATE_DISCONNECTED -> {
                        if (connectedHost == device) {
                            connectedHost = null
                            stopInputReportLoop()
                            notifyStatus(false, "Desconectado de Nintendo Switch", 0)
                        }
                    }
                }
            }

            override fun onInterruptData(device: BluetoothDevice, reportId: Byte, data: ByteArray) {
                // La Switch envía subcomandos con Report ID 0x01 en el canal Interrupt
                if (reportId.toInt() == 0x01 && data.size >= 10) {
                    handleSwitchSubcommand(device, data)
                }
            }

            override fun onSetReport(device: BluetoothDevice, type: Byte, id: Byte, data: ByteArray) {
                if (id.toInt() == 0x01 && data.size >= 10) {
                    handleSwitchSubcommand(device, data)
                }
                hidDevice?.reportError(device, BluetoothHidDevice.ERROR_RSP_SUCCESS)
            }
        })
    }

    /**
     * Responde al Handshake de la Nintendo Switch con Input Report 0x21 (48 bytes de payload).
     */
    private fun handleSwitchSubcommand(device: BluetoothDevice, data: ByteArray) {
        val subcmd = data[9].toInt() and 0xFF
        val reply = ByteArray(48)

        // Encabezado común (Bytes 0..11 son el estado actual del mando)
        fillControllerStateHeader(reply)

        when (subcmd) {
            0x01 -> {
                // Bluetooth Manual Pairing
                reply[12] = 0x81.toByte()
                reply[13] = 0x01.toByte()
                reply[14] = 0x03.toByte()
            }
            0x02 -> {
                // Request Device Info (Firmware 4.89, Tipo de Mando, MAC, Colores SPI activos)
                reply[12] = 0x82.toByte()
                reply[13] = 0x02.toByte()
                reply[14] = 0x04.toByte() // FW Major
                reply[15] = 0x89.toByte() // FW Minor
                reply[16] = controllerType.toByte() // 1=L, 2=R, 3=Pro
                reply[17] = 0x02.toByte()
                // 6 bytes de MAC simulada
                reply[18] = 0x98.toByte()
                reply[19] = 0xB6.toByte()
                reply[20] = 0xE9.toByte()
                reply[21] = 0x44.toByte()
                reply[22] = 0x12.toByte()
                reply[23] = 0x34.toByte()
                reply[24] = 0x01.toByte()
                reply[25] = 0x02.toByte() // Usar colores de SPI 0x6050
            }
            0x10 -> {
                // SPI Flash Read (Calibración y Colores)
                val addrLow = if (data.size > 10) (data[10].toInt() and 0xFF) else 0
                val addrHigh = if (data.size > 11) (data[11].toInt() and 0xFF) else 0
                val addr = addrLow or (addrHigh shl 8)
                val len = if (data.size > 14) (data[14].toInt() and 0xFF) else 0

                reply[12] = 0x90.toByte()
                reply[13] = 0x10.toByte()
                reply[14] = addrLow.toByte()
                reply[15] = addrHigh.toByte()
                reply[16] = 0x00.toByte()
                reply[17] = 0x00.toByte()
                reply[18] = len.toByte()

                when (addr) {
                    0x6050 -> {
                        // Colores del Cuerpo, Botones y Grips
                        System.arraycopy(spiColors, 0, reply, 19, min(len, spiColors.size))
                    }
                    0x603D -> {
                        // Calibración de fábrica de los sticks analógicos (centrados en 0x800)
                        val defaultStickCal = byteArrayOf(
                            0x00.toByte(), 0x07.toByte(), 0x70.toByte(),
                            0x00.toByte(), 0x08.toByte(), 0x80.toByte(),
                            0x00.toByte(), 0x07.toByte(), 0x70.toByte(),
                            0x00.toByte(), 0x07.toByte(), 0x70.toByte(),
                            0x00.toByte(), 0x08.toByte(), 0x80.toByte(),
                            0x00.toByte(), 0x07.toByte(), 0x70.toByte()
                        )
                        System.arraycopy(defaultStickCal, 0, reply, 19, min(len, defaultStickCal.size))
                    }
                    0x6080 -> {
                        // Parámetros físicos de sensores/sticks
                        val params = byteArrayOf(0x50, 0xFD.toByte(), 0x00, 0x00, 0xC6.toByte(), 0x0F)
                        System.arraycopy(params, 0, reply, 19, min(len, params.size))
                    }
                    else -> {
                        // Por defecto 0xFF (sin calibración de usuario personalizada)
                        for (i in 0 until min(len, 29)) {
                            reply[19 + i] = 0xFF.toByte()
                        }
                    }
                }
            }
            0x30 -> {
                // Set Player Lights (LEDs de jugador asignados por la Switch)
                val leds = if (data.size > 10) (data[10].toInt() and 0x0F) else 1
                reply[12] = 0x80.toByte()
                reply[13] = 0x30.toByte()
                notifyStatus(true, "Jugador asignado en la Switch (LED mask: $leds)", leds)
            }
            else -> {
                // ACK estándar (0x03 Set Report Mode, 0x04 Trigger Time, 0x08 Shipment, 0x40 IMU, 0x48 Vibration)
                reply[12] = 0x80.toByte()
                reply[13] = subcmd.toByte()
            }
        }

        hidDevice?.sendReport(device, 0x21, reply)
    }

    private fun fillControllerStateHeader(buf: ByteArray) {
        timerCounter = (timerCounter + 1) and 0xFF
        buf[0] = timerCounter.toByte()
        buf[1] = 0x90.toByte() // Batería llena + info de conexión
        buf[2] = btnRight.toByte()
        buf[3] = btnShared.toByte()
        buf[4] = btnLeft.toByte()

        // Empaquetado de 12 bits para Stick Izquierdo (Bytes 5, 6, 7)
        val lx = stickLX.coerceIn(0, 4095)
        val ly = stickLY.coerceIn(0, 4095)
        buf[5] = (lx and 0xFF).toByte()
        buf[6] = (((lx shr 8) and 0x0F) or ((ly and 0x0F) shl 4)).toByte()
        buf[7] = ((ly shr 4) and 0xFF).toByte()

        // Empaquetado de 12 bits para Stick Derecho (Bytes 8, 9, 10)
        val rx = stickRX.coerceIn(0, 4095)
        val ry = stickRY.coerceIn(0, 4095)
        buf[8] = (rx and 0xFF).toByte()
        buf[9] = (((rx shr 8) and 0x0F) or ((ry and 0x0F) shl 4)).toByte()
        buf[10] = ((ry shr 4) and 0xFF).toByte()

        buf[11] = 0x00.toByte() // Vibrator byte
    }

    private fun startInputReportLoop() {
        stopInputReportLoop()
        reportLoopFuture = executor.scheduleAtFixedRate({
            val host = connectedHost ?: return@scheduleAtFixedRate
            val report = ByteArray(48)
            fillControllerStateHeader(report)
            // Enviar Report ID 0x30 a ~60Hz
            hidDevice?.sendReport(host, 0x30, report)
        }, 0, 16, TimeUnit.MILLISECONDS)
    }

    private fun stopInputReportLoop() {
        reportLoopFuture?.cancel(true)
        reportLoopFuture = null
    }

    fun updateButtonsBitmask(right: Int, shared: Int, left: Int) {
        btnRight = right and 0xFF
        btnShared = shared and 0xFF
        btnLeft = left and 0xFF
    }

    fun updateStick12Bit(isLeft: Boolean, x12: Int, y12: Int) {
        if (isLeft) {
            stickLX = max(0, min(4095, x12))
            stickLY = max(0, min(4095, y12))
        } else {
            stickRX = max(0, min(4095, x12))
            stickRY = max(0, min(4095, y12))
        }
    }

    fun updateSpiColors(bodyRgb: Int, buttonsRgb: Int, leftGripRgb: Int, rightGripRgb: Int) {
        spiColors[0] = ((bodyRgb shr 16) and 0xFF).toByte()
        spiColors[1] = ((bodyRgb shr 8) and 0xFF).toByte()
        spiColors[2] = (bodyRgb and 0xFF).toByte()

        spiColors[3] = ((buttonsRgb shr 16) and 0xFF).toByte()
        spiColors[4] = ((buttonsRgb shr 8) and 0xFF).toByte()
        spiColors[5] = (buttonsRgb and 0xFF).toByte()

        spiColors[6] = ((leftGripRgb shr 16) and 0xFF).toByte()
        spiColors[7] = ((leftGripRgb shr 8) and 0xFF).toByte()
        spiColors[8] = (leftGripRgb and 0xFF).toByte()

        spiColors[9] = ((rightGripRgb shr 16) and 0xFF).toByte()
        spiColors[10] = ((rightGripRgb shr 8) and 0xFF).toByte()
        spiColors[11] = (rightGripRgb and 0xFF).toByte()
    }

    fun stop() {
        stopInputReportLoop()
        try {
            hidDevice?.unregisterApp()
        } catch (_: Exception) {}
        if (originalBtName != null) {
            try {
                bluetoothAdapter?.name = originalBtName
            } catch (_: Exception) {}
        }
    }

    private fun notifyStatus(connected: Boolean, msg: String, leds: Int) {
        mainHandler.post {
            onStatusChange(connected, msg, leds)
        }
    }
}
